package com.lokesh.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.lokesh.entity.Customer;
import com.lokesh.exception.UserAlreadyExistException;
import com.lokesh.exception.UserNotFoundException;
import com.lokesh.repository.CustomerRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AuthorizationService implements UserDetailsService {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		log.info("inside service -> loadUserByUsername ");
		Customer customer = customerRepository.findByUsername(username);
		if (customer == null) {
			log.info("inside service -> loadUserByUsername User NOT Found");
			throw new UsernameNotFoundException("Username Not Found");
		}

		log.info("inside service -> loadUserByUsername User Found");
		return new User(customer.getUsername(), customer.getPassword(), new ArrayList<>());

	}

	public Customer getUser(String username) throws UserNotFoundException {
		Customer customer = customerRepository.findByUsername(username);
		if (customer == null) {
			throw new UserNotFoundException("User Not Found");

		}
		return customer;
	}

	public Customer save(Customer customer) throws UserAlreadyExistException {
		Customer customer2 = customerRepository.findByUsername(customer.getUsername());
		if (customer2 == null) {
//			Customer c = new Customer();O
			Customer customerNew = new Customer();
			customerNew.setName(customer.getName());
			customerNew.setUsername(customer.getUsername());
//			customerNew.setPassword(customer.getPassword());
			customerNew.setPassword(passwordEncoder.encode(customer.getPassword()));
//			u1.setName(customer.getName());
			return customerRepository.save(customerNew);

		}
		throw new UserAlreadyExistException("User Already Exist");
	}

	public Customer getCustomer(String username) throws UserNotFoundException {
		Customer c = customerRepository.findByUsername(username);
		if (c == null) {
//			u.setPassword(bcryptEncoder.encode(user.getPassword()));
			throw new UserNotFoundException("User Not Found");

		}
		return c;
	}

}
